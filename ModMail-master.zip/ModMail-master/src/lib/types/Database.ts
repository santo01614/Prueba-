interface Thread {
	userID: string;
	opened: boolean;
	current?: string;
	total: number;
}

export {
	Thread
};